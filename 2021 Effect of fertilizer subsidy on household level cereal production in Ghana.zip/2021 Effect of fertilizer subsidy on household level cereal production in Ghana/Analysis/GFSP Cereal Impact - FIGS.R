#*******************************************************************************
# Prepared By Francis Tsiboe (ftsiboe@hotmail.com)  
# Citation requirement;
# 1. Tsiboe, F., Egyir, I. S., & Anaman, G (2021). Effect of Fertilizer Subsidy on Household Level Cereal Production in Ghana. 
#            Scientific African, 13. e00916  doi:10.1016/j.sciaf.2021.e00916
# 
# 2. Tsiboe, F. (2020). Nationally Representative Farm/Household Level Dataset on Crop Production in Ghana from 1987-2017.
#*******************************************************************************
#-----------------------------------
# Preliminaries                  ####
rm(list=ls(all=TRUE));library('magrittr');raster::removeTmpFiles(0);library(ggplot2);library(rasterVis)
library(gtable);library(gridExtra);library(ggridges)
#-----------------------------------
# Covariate balance summary      ####

CovBalDATA<-foreign::read.dta("Results/Covariate_balance_summary.dta", convert.f=TRUE)

Diff<-ggplot(data=CovBalDATA[CovBalDATA$Measure=="Standardized differences",], 
             aes(x=Value,y=Coef,group=Type,color=Type)) + 
  geom_point() +
  geom_vline(xintercept = c(0),size = 0.5,color = "black") +
  scale_color_manual(values =c("violet","purple")) +
  labs(title="Standardized differences", x="Differences", y = "\n Covariate",caption ="") +
  facet_wrap(vars(Equ),ncol=2) + 
  theme_bw() +
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.ticks.x = element_blank()) + 
  theme(legend.position="none") +
  theme(legend.text=element_text(size=11),
        legend.title=element_text(size=0),
        axis.title.y=element_text(size=8),
        axis.text.x = element_text(size = 8,vjust=0.5,angle = 0, colour="black"), #
        axis.text.y = element_text(size = 8, colour="black"),
        plot.caption = element_text(size=11, hjust = 0 ,vjust =0, face = "italic"),
        strip.text = element_text(size = 11))

Var<-ggplot(data=CovBalDATA[CovBalDATA$Measure=="Variance ratio",], 
             aes(x=Value,y=Coef,group=Type,color=Type)) + 
  geom_point() +
  geom_vline(xintercept = c(1),size = 0.5,color = "black") +
  scale_color_manual(values =c("violet","purple")) +
  labs(title="Variance ratio", x="Ratio", y = "\n Covariate",caption ="") +
  facet_wrap(vars(Equ),ncol=2) + 
  theme_bw() +
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.ticks.x = element_blank()) + 
  theme(legend.position="bottom") +
  theme(legend.text=element_text(size=11),
        legend.title=element_text(size=0),
        axis.title.y=element_text(size=8),
        axis.text.x = element_text(size = 8,vjust=0.5,angle = 0, colour="black"), #
        axis.text.y = element_text(size = 8, colour="black"),
        plot.caption = element_text(size=11, hjust = 0 ,vjust =0, face = "italic"),
        strip.text = element_text(size = 11))

Figure1<-cowplot::plot_grid(Diff ,Var,ncol=1, align="v",greedy=F)
ggsave("Results/Figure1.png", Figure1,dpi = 600,width = 7, height = 9)
#-----------------------------------
# Propensity score overlap       ####
OverlapDATA<-foreign::read.dta("Results/OverLapsFigData.dta", convert.f=TRUE)
OverlapDATA$Subsidy<-factor(OverlapDATA$Subsidy,levels = c(0,1),labels = c("Non-subsidy households    ","Subsidy households"))
OverlapDATA_1<-rbind(OverlapDATA[OverlapDATA$MatchID %in% 
                                   unique(OverlapDATA[OverlapDATA$Subsidy %in% "Subsidy households","PSM_1"]),],
                     OverlapDATA[OverlapDATA$Subsidy %in% "Subsidy households",])
OverlapDATA_0<-OverlapDATA
OverlapDATA_1$Type<-1
OverlapDATA_0$Type<-0
OverlapDATA<-rbind(OverlapDATA_1,OverlapDATA_0)
OverlapDATA$Type<-factor(OverlapDATA$Type,levels = c(0,1),labels = c("Pre-match    ","Post-match"))

Overlap1<-ggplot(data=OverlapDATA, aes(x=PSM_Score,group=Subsidy,color=Subsidy)) + 
  geom_density() +
  scale_color_manual(values =c("purple","violet")) +
  labs(title="Density", x="PSM Score", y = "\n Density",caption ="") +
  facet_wrap(vars(Type),ncol=2) + 
  theme_bw() +
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.ticks.x = element_blank()) + 
  theme(legend.position="none") +
  theme(legend.text=element_text(size=11),
        legend.title=element_text(size=0),
        axis.title.y=element_text(size=11),
        axis.text.x = element_text(size = 11,vjust=0.5,angle = 0, colour="black"), #
        axis.text.y = element_text(size = 11, colour="black"),
        plot.caption = element_text(size=11, hjust = 0 ,vjust =0, face = "italic"),
        strip.text = element_text(size = 11))

Overlap2<-ggplot(data=OverlapDATA, aes(x=PSM_Score,group=Subsidy,color=Subsidy)) + 
  stat_ecdf() +
  scale_color_manual(values =c("purple","violet")) +
  labs(title="Empirical cumulative distribution", x="PSM Score", y = "\n\nCumulative probability",caption ="") +
  facet_wrap(vars(Type),ncol=2) + 
  theme_bw() +
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.ticks.x = element_blank()) + 
  theme(legend.position="bottom") +
  theme(legend.text=element_text(size=11),
        legend.title=element_text(size=0),
        axis.title.y=element_text(size=11),
        axis.text.x = element_text(size = 11,vjust=0.5,angle = 0, colour="black"), #
        axis.text.y = element_text(size = 11, colour="black"),
        plot.caption = element_text(size=11, hjust = 0 ,vjust =0, face = "italic"),
        strip.text = element_text(size = 11))

Figure2<-cowplot::plot_grid(Overlap1,Overlap2,ncol=1, align="v",rel_heights=c(1, 1),greedy=F)
ggsave("Results/Figure2.png", Figure2,dpi = 600,width = 7, height = 9)

#-----------------------------------
# Yield Treatment Effect         ####
MATCH<-rbind(foreign::read.dta("Results/NNM_Yield_Results.dta", convert.f=TRUE),
             foreign::read.dta("Results/PSM_Yield_Results.dta", convert.f=TRUE))

Fxn.Robust <- function(crop){
  data<-MATCH[(MATCH$CropID==crop),]
  Index<-doBy::summaryBy(list(c("b"),c("matching","Nnbr","Type")),
                         data=data,FUN=mean,keep.names = T)
  Index<-Index[order(Index$Type,Index$b),]
  Index$Index<-1:nrow(Index)
  Index$Mid<-ifelse(Index$Type == c(NA,Index[1:(nrow(Index)-1),"Type"]),NA,Index$Index)
  Index$Index<-ifelse(Index$Index>=min(Index$Mid,na.rm=T),Index$Index+1,Index$Index-1)
  Index_i<-Index[1,]
  Index_i$Index<-min(Index$Mid,na.rm=T)
  Index_i$Type<-"d"
  Index_i$matching<-NA
  Index_i$Nnbr<-NA
  Index<-rbind(Index_i,Index)
  data<-dplyr::full_join(data,Index[c("matching","Nnbr","Index","Type")],
                         by=c("matching","Nnbr","Type"))
  data$Grp<-ifelse(data$Type=="ATE","1","2")
  data$Grp<-ifelse(data$Type=="ATET","3",data$Grp)
  data$x<-as.numeric(as.factor(as.character(paste0(data$Grp, data$Index))))
  data$Grp<-ifelse(data$Type=="ATE","Sample average treatment effect (SATE)","")
  data$Grp<-ifelse(data$Type=="ATET","Sample average treatment effect on the treated (SATET)",data$Grp)
  
  Index_prf<-data[(data$matching=="mahalanobis" & data$Nnbr==1),]
  
  Outcome<-ggplot(data=data[!data$b %in% NA,],aes(x=x, y=(exp(b)-1)*100,group=Grp,fill=Grp,colour=Grp)) +
    geom_hline(aes(yintercept=0), lwd=1, lty=2,color = "blue",fill = "blue") + 
    geom_errorbar(aes(ymax = (exp(b + se*1.96)-1)*100, ymin = (exp(b - se*1.96)-1)*100), width = 0.25) +
    geom_point(colour="black",pch=21, size=2) + 
    geom_vline(xintercept = data[data$b %in% NA,"x"],size = 0.5,color = "black") +
    geom_point(data=Index_prf,pch=21, size=2,fill="black",colour="black") + 
    scale_fill_manual(values = c("purple","violet")) +
    scale_color_manual(values =c("purple","violet")) +
    labs(title="", x="", y = "\nTreatment effect (%)",caption ="") +
    theme_bw() +
    theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.ticks.x = element_blank()) + 
    theme(legend.position="top") +
    theme(legend.text=element_text(size=8),
          legend.title=element_text(size=0),
          axis.title.y=element_text(size=10),
          axis.text.x = element_text(size = 0,vjust=0.5,angle = 0, colour="black"), #
          axis.text.y = element_text(size = 10, colour="black"),
          plot.caption = element_text(size=10, hjust = 0 ,vjust =0, face = "italic"),
          strip.text = element_text(size = 11));Outcome
  
  
  # Neighbors
  dataC<-doBy::summaryBy(b~Nnbr+x,data=data,FUN=mean,keep.names = T)
  Neighbor<-ggplot() +
    geom_point(data=dataC[!dataC$Nnbr %in% NA,],aes(x=x,y=as.factor(Nnbr)),color="black",pch=21, size=2) + 
    geom_point(data=dataC[dataC$x %in% Index_prf$x,],aes(x=x,y=as.factor(Nnbr)),colour="black", size=2) + 
    geom_vline(xintercept = dataC[dataC$b %in% NA,"x"],size = 0.5,color = "black") +
    labs(title="", x="", y = "\nNumber of neighbors",caption ="") +
    theme_bw() +
    theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.ticks.x = element_blank()) + 
    theme(legend.position="top") +
    theme(legend.text=element_text(size=8),
          legend.title=element_text(size=0),
          axis.title.y=element_text(size=10),
          axis.text.x = element_text(size = 0,vjust=0.5,angle = 0, colour="black"), #
          axis.text.y = element_text(size = 10, colour="black"),
          plot.caption = element_text(size=10, hjust = 0 ,vjust =0, face = "italic"),
          strip.text = element_text(size = 11));Neighbor
  
  
  
  # Neighbors
  dataA<-doBy::summaryBy(b~matching+x,data=data,FUN=mean,keep.names = T)
  matching<-ggplot() +
    geom_point(data=dataA[!dataA$matching %in% NA,],aes(x=x,y=as.factor(matching)),color="black",pch=21, size=2) + 
    geom_point(data=dataA[dataA$x %in% Index_prf$x,],aes(x=x,y=as.factor(matching)),colour="black", size=2) + 
    geom_vline(xintercept = dataA[dataA$b %in% NA,"x"],size = 0.5,color = "black") +
    labs(title="", x="", y = "\nMatching estimator",caption ="") +
    theme_bw() +
    theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.ticks.x = element_blank()) + 
    theme(legend.position="top") +
    theme(legend.text=element_text(size=8),
          legend.title=element_text(size=0),
          axis.title.y=element_text(size=10),
          axis.text.x = element_text(size = 0,vjust=0.5,angle = 0, colour="black"), #
          axis.text.y = element_text(size = 10, colour="black"),
          plot.caption = element_text(size=10, hjust = 0 ,vjust =0, face = "italic"),
          strip.text = element_text(size = 11));matching
  
  
  
  pad<-c(-0.9,0.5,-0.9,0.5)
  Robust<-cowplot::plot_grid(Outcome + theme(plot.margin=unit(c(0.05,0.5,-0.9,0.5), "cm")),
                             Neighbor + theme(plot.margin=unit(pad, "cm")),
                             matching + theme(plot.margin=unit(pad, "cm")),
                             ncol=1, align="v",rel_heights=c(1, 0.25, 0.25, 0.25, 0.25),
                             greedy=F);Robust
  return(Robust)
}



ggsave("Results/Yield_Treatment_Effect_1.png", Fxn.Robust(1),dpi = 600,width = 7, height = 8)
ggsave("Results/Yield_Treatment_Effect_2.png", Fxn.Robust(2),dpi = 600,width = 7, height = 8)
ggsave("Results/Yield_Treatment_Effect_3.png", Fxn.Robust(3),dpi = 600,width = 7, height = 8)
ggsave("Results/Yield_Treatment_Effect_4.png", Fxn.Robust(4),dpi = 600,width = 7, height = 8)
ggsave("Results/Yield_Treatment_Effect_5.png", Fxn.Robust(5),dpi = 600,width = 7, height = 8)

